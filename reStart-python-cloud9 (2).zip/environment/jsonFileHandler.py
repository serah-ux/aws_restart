import json

def readJsonFile(fileName):
    data = ""
    try:
        with open(fileName, 'r') as json_file:
            data = json.load(json_file)
    except IOError:
        print("Could not read file")
    return data

data = readJsonFile('files/insulin.json')

if data:
    bInsulin = data['molecules'].get('bInsulin', 'fvnqhlcgshlvealylvcgergffytpkt')
    aInsulin = data['molecules'].get('aInsulin', 'giveqcctsicslyqlenycn')
    molecularWeightInsulinActual = data.get('molecularWeightInsulinActual', 5807.63)
    
    print('bInsulin: ' + bInsulin)
    print('aInsulin: ' + aInsulin)
    print('molecularWeightInsulinActual: ' + str(molecularWeightInsulinActual))
else:
    print("Error. Exiting program")
